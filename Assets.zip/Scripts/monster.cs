﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class monster : MonoBehaviour
{
    // Start is called before the first frame update

    float speed = 3f;
    float speed2 = 6f;

    float rotationSpeed = 6f;
    float initialRotation = 0f;
    float gravity = 3f;

    Vector3 moveDirection = Vector3.zero;
    CharacterController controller;

    Animator miAnimator;

    // Start is called before the first frame update
    void Start()
    {
        controller = GetComponent<CharacterController>();
        miAnimator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        

        moveDirection.y -= gravity * Time.deltaTime;
        controller.Move(moveDirection * Time.deltaTime);
    }
}